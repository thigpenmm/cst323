
<!DOCTYPE html>
<html>
<head>
<style>
body {font-family: Calibri, Helvetica, sans-serif;}
* {box-sizing: border-box}

.container {
	width: 500px;
	height: 450px;
	text-align: center;
	margin: 0 auto;
	background-color: rgba(44, 62, 80,0.7);
	margin-top: 160px;
}
}
 

}
</style>

<title> Login </title>
</head>
<body>
<div class="container">
<form>
<div class="form-input">
<h1 style="color:white;"> <br> My Supply Store</h1>
<h2 style="color:white;"> <br> Mercedes Thigpen</h2>
<h2 style="color:white;"> <br> CST-236</h2>

</div>
<div class="form-input">
<span><h2><a style= "color: Cyan;" href="registration.php">Register</a></h2></span> <span><h2><a style="color: lightCyan;" href="login.html">Login</a></h2></span> 
</div>
</form>
</div>
</body>
</html>
